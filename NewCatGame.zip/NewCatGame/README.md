# NewCatGame
Improved Cat Game 

Prerequisites:
Visual Studios 2022

Language(s):
HTML, CSS, and Javascript

Game:
I edited the code from Cat game (Thank you DevanshKyada27) for my college final. I changed the code so the user can change the body and ear color of the cat instead of using accessories. 
