// Select elements for accessory toggles and color inputs
const hatcheck = document.querySelector("#hat");
const glassescheck = document.querySelector("#eyeglasses");
const tiecheck = document.querySelector("#tie");

const hat = document.querySelector(".hat");
const glasses = document.querySelector(".glasses");
const tie = document.querySelector(".tie");

const bodyColorInput = document.querySelector("#bodyColor");
const earColorInput = document.querySelector("#earColor");

const body = document.querySelector(".body");
const ears = document.querySelectorAll(".ear");

// Accessory toggle functions
hatcheck.addEventListener("change", () => {
    if (hatcheck.checked) {
        hat.style.visibility = "visible";
        hat.style.opacity = "1";
    } else {
        hat.style.visibility = "hidden";
        hat.style.opacity = "0";
    }
});

glassescheck.addEventListener("change", () => {
    if (glassescheck.checked) {
        glasses.style.visibility = "visible";
        glasses.style.opacity = "1";
    } else {
        glasses.style.visibility = "hidden";
        glasses.style.opacity = "0";
    }
});

tiecheck.addEventListener("change", () => {
    if (tiecheck.checked) {
        tie.style.visibility = "visible";
        tie.style.opacity = "1";
    } else {
        tie.style.visibility = "hidden";
        tie.style.opacity = "0";
    }
});

// Color customization functions
bodyColorInput.addEventListener("input", (e) => {
    body.style.backgroundColor = e.target.value;
});

earColorInput.addEventListener("input", (e) => {
    ears.forEach(ear => ear.style.backgroundColor = e.target.value);
});


